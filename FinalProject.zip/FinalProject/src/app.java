
import java.util.Scanner;

public class app {
    
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int hour;
        int minute = 0;
        
        String location1;
        String location2;
        String again;
        app obj = new app();
        
        do {
            System.out.println("======================================");
            System.out.println("ASEAN Time Converter");
            System.out.println("======================================");
            System.out.println("Where Are You From : ");
            System.out.println("1. Indonesia Barat");
            System.out.println("2. Indonesia Tengah");
            System.out.println("3. Indonesia Timur");
            System.out.println("4. Malaysia");
            System.out.println("5. Singapore");
            System.out.println("6. Vietnam");
            System.out.println("7. Thailand");
            System.out.println("8. Kamboja");
            System.out.println("9. Laos");
            System.out.println("10. Brunei");
            System.out.println("11. Philippines");
            System.out.println("12. Myanmar");
            System.out.print("Choose : ");
            location1 = scan.next() + scan.nextLine();
            
            do {
                System.out.print("Input Your Hour : ");
                hour = scan.nextInt();
                
                if (hour > 23 || hour < 0) {
                    System.out.println("Input Tidak Valid");
                }
            } while (hour > 23 || hour < 0);
            
            do {
                System.out.print("Input Your Minute : ");
                minute = scan.nextInt();
                
                if (minute > 59 || minute < 0) {
                    System.out.println("Input Tidak Valid");
                }
            } while (minute > 59 || minute < 0);
            
            if (location1.equalsIgnoreCase("Indonesia Barat")) {
                System.out.println("======================================");
                System.out.println("Choose");
                System.out.println("======================================");
                System.out.println("1. Indonesia Tengah");
                System.out.println("2. Indonesia Timur");
                System.out.println("3. Malaysia");
                System.out.println("4. Singapore");
                System.out.println("5. Vietnam");
                System.out.println("6. Thailand");
                System.out.println("7. Kamboja");
                System.out.println("8. Laos");
                System.out.println("9. Brunei");
                System.out.println("10. Philippines");
                System.out.println("11. Myanmar");
                System.out.print("Choose: ");
                location2 = scan.next() + scan.nextLine();
                
                if (location2.equalsIgnoreCase("Indonesia Tengah") || location2.equalsIgnoreCase("Malaysia") || location2.equalsIgnoreCase("Singapore") || location2.equalsIgnoreCase("Philippines")) {
                    System.out.println("The time is " + obj.plusone(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Indonesia Timur")) {
                    System.out.println("The time is " + obj.plustwo(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Kamboja") || location2.equalsIgnoreCase("Laos") || location2.equalsIgnoreCase("Thailand") || location2.equalsIgnoreCase("Vietnam")) {
                    System.out.println("The time is " + hour + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Myanmar")) {
                    obj.plushalf(hour, minute);
                }
            } else if (location1.equalsIgnoreCase("Indonesia Tengah")) {
                System.out.println("======================================");
                System.out.println("Choose");
                System.out.println("======================================");
                System.out.println("1. Indonesia Barat");
                System.out.println("2. Indonesia Timur");
                System.out.println("3. Malaysia");
                System.out.println("4. Singapore");
                System.out.println("5. Vietnam");
                System.out.println("6. Thailand");
                System.out.println("7. Kamboja");
                System.out.println("8. Laos");
                System.out.println("9. Brunei");
                System.out.println("10. Philippines");
                System.out.println("11. Myanmar");
                System.out.print("Choose: ");
                location2 = scan.next() + scan.nextLine();
                
                if (location2.equalsIgnoreCase("Indonesia Barat") || location2.equalsIgnoreCase("Kamboja") || location2.equalsIgnoreCase("Laos") || location2.equalsIgnoreCase("Thailand") || location2.equalsIgnoreCase("Vietnam")) {
                    System.out.println("The time is " + obj.minusone(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Brunei") || location2.equalsIgnoreCase("Malaysia") || location2.equalsIgnoreCase("Singapore") || location2.equalsIgnoreCase("Philippines")) {
                    System.out.println("The time is " + hour + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Indonesia Timur")) {
                    System.out.println("The time is " + obj.plusone(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Myanmar")) {
                    obj.plusonehalf(hour, minute);
                }
            } else if (location1.equalsIgnoreCase("Indonesia Timur")) {
                System.out.println("======================================");
                System.out.println("Choose");
                System.out.println("======================================");
                System.out.println("1. Indonesia Barat");
                System.out.println("2. Indonesia Tengah");
                System.out.println("3. Malaysia");
                System.out.println("4. Singapore");
                System.out.println("5. Vietnam");
                System.out.println("6. Thailand");
                System.out.println("7. Kamboja");
                System.out.println("8. Laos");
                System.out.println("9. Brunei");
                System.out.println("10. Philippines");
                System.out.println("11. Myanmar");
                System.out.print("Choose: ");
                location2 = scan.next() + scan.nextLine();
                
                if (location2.equalsIgnoreCase("Indonesia Barat") || location2.equalsIgnoreCase("Kamboja") || location2.equalsIgnoreCase("Laos") || location2.equalsIgnoreCase("Thailand") || location2.equalsIgnoreCase("Vietnam")) {
                    System.out.println("The time is " + obj.minustwo(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Indonesia Tengah") || location2.equalsIgnoreCase("Brunei") || location2.equalsIgnoreCase("Malaysia") || location2.equalsIgnoreCase("Philippines") || location2.equalsIgnoreCase("Singapore")) {
                    System.out.println("The time is " + obj.minusone(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Myanmar")) {
                    obj.minustwohalf(hour, minute);
                }
            } else if (location1.equalsIgnoreCase("Malaysia")) {
                System.out.println("======================================");
                System.out.println("Choose");
                System.out.println("======================================");
                System.out.println("1. Indonesia Barat");
                System.out.println("2. Indonesia Tengah");
                System.out.println("3. Indonesia Timur");
                System.out.println("4. Singapore");
                System.out.println("5. Vietnam");
                System.out.println("6. Thailand");
                System.out.println("7. Kamboja");
                System.out.println("8. Laos");
                System.out.println("9. Brunei");
                System.out.println("10. Philippines");
                System.out.println("11. Myanmar");
                System.out.print("Choose: ");
                location2 = scan.next() + scan.nextLine();
                
                if (location2.equalsIgnoreCase("Indonesia Barat") || location2.equalsIgnoreCase("Kamboja") || location2.equalsIgnoreCase("Laos") || location2.equalsIgnoreCase("Thailand") || location2.equalsIgnoreCase("Vietnam")) {
                    System.out.println("The time is " + obj.minusone(hour) + ":" + String.format("%02d", minute));
                } else if (location2.equalsIgnoreCase("Indonesia Tengah") || location2.equalsIgnoreCase("Brunei") || location2.equalsIgnoreCase("Philippines") || location2.equalsIgnoreCase("Singapore")) {
                    System.out.println("The time is " + hour + ":" + String.format("%02d", minute));
                } else if(location2.equalsIgnoreCase("Indonesia Timur")){
                    System.out.println("The time is " + obj.plusone(hour) + ":" + String.format("%02d", minute));
                } else if(location2.equalsIgnoreCase("Myanmar")){
                    obj.minusonehalf(hour, minute);
                }
            } else {
                System.out.println("Salah input");
            }
            
            System.out.println("Want to do it again? (Y/N)");
            again = scan.next();
            
            if (again.equalsIgnoreCase("n")) {
                System.out.println("Thank You See You Next Time");
            }
        } while (again.equalsIgnoreCase("y"));
    }
    
    public int plusone(int angka1) {
        int hasil = 0;
        hasil = angka1 + 1;
        return hasil;
    }
    
    public int plustwo(int angka1) {
        int hasil = 0;
        hasil = angka1 + 2;
        return hasil;
    }
    
    public void plushalf(int angka1, int angka2) {
        
    }
    
    public void plusonehalf(int angka1, int angka2) {
        
    }
    
    public int minusone(int angka1) {
        int hasil = 0;
        hasil = angka1 - 1;
        return hasil;
    }
    
    public int minustwo(int angka1) {
        int hasil = 0;
        hasil = angka1 - 2;
        return hasil;
    }

    public void minustwohalf(int angka1, int angka2) {
        
    }
    
    public void minusonehalf(int angka1, int angka2){
        
    }
}
